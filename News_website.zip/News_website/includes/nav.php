<?php 
include_once('head.php');
?>

<nav>
  <div class="navbar">
    <div class="logo">
      <h3>LOGO</h3>
    </div>
    <div class="search-bar">
    <input type="text" name="search">
    <button>search</button>
    </div>
    <div class="manu">
      <ul>
      <li><a href="#home">Latest News</a></li>
      <li><a href="#home">Politics</a></li>
      <li><a href="#home">Sports</a></li>
      <li><a href="#home">Entertainment</a></li>
      <li><a href="#home">Sci & Tech</a></li>
      <li><a href="#home">World</a></li>
      </ul>
    </div>
    <div class="nav-buttons">
    <div id="search-btn"><i class="fa fa-search"></i></div>
    <div class="menu-btn"><i class="fa fa-bars"></i></div>
    </div>
  </div>
</nav>

<?php
include_once('includes/nav.php');
?>

<main>
<div class="main-container">

 <div class="wrapper1">
   <div class="wrapper-box1">
   </div>
   <div class="wrapper-box2">
   </div>
 </div>

<div class="wrapper2">
   <div class="wrapper2-box1">
   </div>
   <div class="wrapper2-box1">
   </div>
</div>

<div class="wrapper3">
   <div class="wrapper3-box1">
   </div>
   <div class="wrapper3-box2">
   </div>
   <div class="wrapper3-box3">
   </div>
</div>

</div>
</main>


<?php
include_once('includes/footer.php');
?>